#!/usr/bin/env bash
# Runs the plan one goal per Claude Code session so context stays fresh.
# Usage (inside the Codespace, repo root): bash scripts/run-goals.sh
# Check your permission flags first with: claude --help
set -u
CLAUDE_FLAGS="${CLAUDE_FLAGS:-}"   # example: set your permission mode here
GOALS="G0 G1 G2 G3 G4 G5 G6 G7 G8 G9 G10 G11 G12 G13"
git checkout -B build/revamp
for G in $GOALS; do
  echo "=== Starting $G ==="
  claude -p $CLAUDE_FLAGS "/goal Read docs/MASTER_PROMPT.md and follow it. Complete goal $G from section 6: docs/PLAN_STATUS.md has $G checked, TRACE.md has a $G entry marking every DONE condition pass or a reasoned blocker, pnpm lint, pnpm test and pnpm build exit 0, and the $G commit is pushed to origin/build/revamp (git status clean). Stop after 60 turns and write blockers to TRACE.md."
  git push origin build/revamp || true
done
echo "All goals attempted. Read docs/PLAN_STATUS.md and docs/KEYS_NEEDED.md"
