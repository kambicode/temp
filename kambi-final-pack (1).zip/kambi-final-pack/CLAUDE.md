# KAMBi - Agent Context (CLAUDE.md)

Read this first, every session. It is the reconciled source of truth. Where code or older docs disagree with it, this file wins. Items marked DECISION NEEDED are open: use the stated default, flag it in TRACE.md, do not silently choose otherwise. Full conflict list: docs/RECONCILIATION.md. Feature IDs and DONE conditions: docs/KAMBI_FEATURE_TREE.md.

Autonomous build instructions: docs/MASTER_PROMPT.md. Follow it when told to run goals.

## 1. Working rules
- Tell the founder what is needed, backed by researched best practice. Be straight. Do not repeat his points back.
- Every system includes an HQ (headquarters) console. Never design a user-only product.
- Write the long form of every acronym the first time it appears in a document.
- Use regular hyphens only. No em dashes or en dashes.
- Work one feature ID at a time: write the test from the DONE condition first, then the code, then report which DONE conditions pass. Log every step in TRACE.md. No phase is complete without an audit and a checkpoint. (Skill: kambi-feature-gate)
- Never ship a secret in a client bundle. Never keep business logic only on the client. Only MIT, Apache 2.0 or BSD dependencies; flag GPL, AGPL, FSL (Functional Source License) or other source-available licences before use. (Skill: kambi-license-and-secrets)
- Never invent numbers, field results or testimonials in any UI or copy.
- Before any feature that touches personal data, run the privacy gate. (Skill: kambi-privacy-gate)

## 2. What KAMBi is
A social research tool and "best friend in impact" for camp organizers, outreach teams and field researchers in any domain (sciences, liberties, arts, finances). Medicine is one template; never assume patients in shared code. Positioning: "We don't own data, we own the railway." KAMBi carries a record from camp to reminder to referral to the receiving institution; the data belongs to the event owner.
The loop (Ouroboros): create, plan, execute, review, follow up, reflect, then back to create. Follow-up is the differentiator. Published findings feed new creation.
Public name: Kambi.camp. KAMBi is a Nama Labs venture (not yet incorporated; signed on trust with partners). ClerQ Intelligence is an affiliate and must not appear in any user-facing text, public page, report header or generated document. Support email: kambi.camp@gmail.com. Based in Dar es Salaam, Tanzania. Predecessor: Ria (Rotary and Rotaract in Action), which failed on market fit and business model; do not repeat that.
The AI synthesis engine is named Ahadi.

## 3. Planes, accounts and roles
- Three planes: ordinary users, enterprises, HQ.
- Accounts: user accounts and HQ staff accounts only. An enterprise is an organization entity with member roles and its own console, not a third kind of person. One user account can host one event and collect in another; event roles (Owner, Supervisor, Collector, Viewer) live on the event.
- Most participants and patients never get accounts: they exist as a registration, a QR (Quick Response) slip and a consent record.
- Enterprise types: camp-running organizations, health facilities, research institutions, later sponsors. Enterprises create official organizations; users affiliate and the enterprise accepts. Personal organizations created by users are separate. Unverified enterprises run in sandbox with demo data only.
- HQ roles: Master, Support, Security, Trust and Safety, Network and Maintenance, Finance, Decisions, Compliance and DPO (Data Protection Officer), Auditor. Ship V1 with Master, Support, Security, Finance and DPO; others as flags. Role changes need two people. HQ never sees raw entry data or private chats; patient-level access only through audited break-glass (reason code, second approver, time limit, review ticket). HQ is English only, used on laptop and phone. HQ sits behind Cloudflare Access on its own domain.

## 4. Design language: Quiet Rail (skill: kambi-design-language)
Inspired by Dieter Rams, Jony Ive, Bernays (symbol and ritual, with an ethical limit) and a typography reference ("Kobs", unconfirmed, likely Akira Kobayashi). Minimalist, fluid, Apple-inspired, interactive spring motion. No emojis in app chrome or icons, only vector icons; native emojis in user text are replaced by the built-in animated set. No preset chips, tags or pills. Copy is plain and grounded, never AI filler. Glass only on navigation and sheets. One ember accent (#D9501E family) for the primary action and live or sync state. Respect reduced motion. Design every state: empty, offline, failed, syncing.

## 5. Product decisions
- Surfaces: S1 marketing site, S2 user web and PWA (Progressive Web App) for iPhone, S3 Android via Expo EAS (Expo Application Services) with React Native, S4 enterprise console, S5 HQ console, S6 orchestration on the VPS (virtual private server). Each console is its own Cloudflare Pages project and domain. Separate pages are not a security boundary: use row-level security, per-console database roles and server-side checks.
- Tabs (vision): Social, Chats, Home, Camps, Library; You at top right. Mobile bar order: Feed, Chat, Home, Camps, Library. DEFAULT for camp one: ship Home, Camps, You only; everything else flag-driven (Library read-only first, then Feed, then Chat).
- Pricing (public): first 100 entries free, then 100 TZS (Tanzanian shillings) per entry, pay as you go. Swahili shows "TSh 100"; English shows the dollar equivalent from a daily rate (fall back to TSh, never guess). If a user does not pay, they only get the rule-based outputs (the system summary report with graphs, and the data spreadsheet/CSV). AI-written outputs and SMS (Short Message Service) are paid per use with the bill shown before confirmation. Paid entries get 365-day Entry Storage(TM), the intelligent service (duplicate and missing-field checks on sync) and publication to Zenodo and other open platforms (flag off for camp one). Entries on the free allowance, unpaid entries and entries past the quota are kept 90 days after the event closes, with warnings at 30 and 7 days, and the owner can always export them; they are never hidden or locked. No subscriptions.
- HQ quota grants: HQ can grant any camp or organization a limit-based quota (entries, SMS, AI) on prepaid or credit-line terms, with an expiry; grant-covered entries count as paid for retention. Usage is metered against the grant and an invoice is raised at event close ("bill at the end"). Grants need an approver and write an audit event. The first partner (SIKI, Sauti Inayojenga Kesho Initiative) is handled this way: no hard-coded partner logic.
- Billing rails: prepaid wallet; Payme Africa (payer covers surcharge) plus manual mobile money confirmed by HQ. SMS via Textify with delivery status and segment counts.
- AI: runs by cron through OpenRouter on cheap models. A small model first classifies which fields are safe; only anonymized fields leave the device or server; redaction runs locally; names and phones never reach any model. At event end the user receives all selected AI outputs in the inbox at once; every event also gets a system summary document. A nightly job writes a personal development synopsis. Feed ranking starts as a small rules script on cron.
- Moderation: sensitive posts held, first LLM (large language model) decision, second LLM audit, then publish or block, with human appeal. Social features are free.
- Capture: offline first, automatic and manual sync, location and device state with permission, audio important, video later. Caps: DECISION NEEDED (RECONCILIATION 6); default 1 MB per image, 5 MB per entry, 50 MB per event.
- Auth: Google sign-in plus phone one-time code over SMS. No email codes (Supabase email limits hurt). DECISION NEEDED if Supabase Auth is kept at all.
- Languages: English and Swahili everywhere except HQ (English only); built to add more.

## 6. Architecture
Supabase free tier for the pilot (media in object storage, not the database); later Supabase Pro or self-hosted Postgres. Oracle Always Free Arm VPS for compute; start with ONE server and add more only when a real bottleneck appears; several single-purpose servers under an orchestrator is the later plan. Real-time over WebSocket push, never fixed polling (Centrifugo, Apache 2.0, or Supabase Realtime for now). Offline sync candidates: WatermelonDB (MIT), ElectricSQL or RxDB (Apache 2.0); PowerSync is source-available. Consoles: Refine (MIT). Mobile hardening: Hermes bytecode, R8 and ProGuard, stripped logs and source maps, certificate pinning, request signing, root detection as a speed bump only. Keys and AI prompts live on a server-side proxy. Analytics: anonymous only (Umami or PostHog), fixed event schema, no health content. Test stack today: Supabase free, Cloudflare Pages, GitHub Actions cron, OpenRouter free models, Textify. Repo: github.com/Kambi-camp/Kambi.

## 7. Legal: Tanzania PDPA (Personal Data Protection Act, Chapter 44)
Register with the Personal Data Protection Commission before collecting or processing personal data (s14; five years). Reported smallest-category fee TZS 100,000, renewal TZS 50,000 per five years (verify). Appoint a DPO (s27(3)); sign processor contracts (SMS, AI, hosting; s27(4)); notify breaches without undue delay (s27(5)); tell people purposes and recipients before collecting (s23(2)); sensitive data (health, children, biometric, financial) needs prior written, withdrawable consent, guardian consent for minors (s30); corrections keep earlier versions (s29(2)); people can refuse solely automated decisions (s36) and stop direct marketing (s35); submit a code of ethics (s65). Room: medical exception (s30(5)(f)), de-identified research reuse (s25(2)(d)), proportional security (s27(2)), consent-based cross-border transfer (s32(4)), paid data deals by agreement (s35(2)). No startup exemption; penalties reach TZS 100 million administrative and officers can be personally liable. Registration must happen before real patient data is collected at the first camp. Test data only until then. Lawyer review of the 2023 Regulations, controller and processor roles, and hosting location is still pending.

## 8. Not now
Knowledge graph and device-profiling engine (Phase 6, flag off, coarse anonymous buckets only). Data marketplace (only after Commission guidance; leave room in privacy policy and terms). Video capture. Multiple Oracle servers. Subscriptions.

## 9. Open items to raise, not decide
Real patient data before registration and hosting are settled. Chat UI kit, stories UI, QR signing and PDF libraries (licences unverified). Controller versus processor between Nama Labs and each organizer. Whether duplicate entries are billable. Enterprise pricing and seat model. Everything marked DECISION NEEDED in docs/RECONCILIATION.md.
