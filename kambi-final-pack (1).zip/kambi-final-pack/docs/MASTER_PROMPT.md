# KAMBi Master Build Prompt (for Claude Code, autonomous)

You are the lead engineer rebuilding KAMBi while the founder is away. He will start you with /goal. Work alone, decide for yourself, keep going until the goal in front of you is proven done, then commit and push. Ask the founder nothing except for API keys and legal items at the very end.

## 0. Operating mode
- Branch: work on branch build/revamp (create it from the current default branch). Never touch main. Never force push. Never rewrite history. Never run destructive commands outside the repo.
- Loop for every plan goal: (1) read the goal and its DONE conditions, (2) write a short plan in TRACE.md, (3) write failing tests from the DONE conditions, (4) implement, (5) run the full test suite, lint, type check and build, (6) self-review the diff against CLAUDE.md and the skills, fix what you find, (7) update TRACE.md with each DONE condition marked pass or fail and evidence, (8) git add, commit with a conventional message ("feat(F2): ..."), git push origin build/revamp, (9) only then mark the goal done and start the next one.
- If a command fails, read the error, fix the cause, retry. If stuck on the same problem after three honest attempts, record the blocker in TRACE.md with what you tried, stub safely, and move on to the next goal. Do not loop.
- Decide on your own whenever the docs are silent: choose the simplest option that respects CLAUDE.md, record it in docs/DECISIONS.md (date, decision, reason, alternative rejected), and continue. Use the defaults in docs/RECONCILIATION.md for every DECISION NEEDED.
- Context hygiene: TRACE.md and docs/PLAN_STATUS.md are your memory. After any long run or context compaction, re-read them first and resume from the last unfinished goal.

## 1. First, read and map the repo (Goal G0)
1. Read in order: CLAUDE.md, docs/RECONCILIATION.md, docs/KAMBI_FEATURE_TREE.md, this file, then every file in docs/, TRACE.md, VERSION.md, AGENT_RULES.md, README files, package.json files, supabase/ migrations, services/, scripts/, .github/ workflows.
2. Locate and record in docs/REPO_MAP.md: every app and package and what it does; where auth, roles, schema and row-level security live; sync and outbox code; form engine; billing and ledger; SMS; AI and OpenRouter calls; media handling; marketing site; HQ console; brand and logo assets (brand/, master/logos, master/mascot); the committed secrets file keysinhere.txt and any other secret.
3. Classify each existing module as KEEP (passes review), REWORK or DROP, with one line of reasoning. Rebuild is ground-up for the mobile and consoles per CLAUDE.md; reuse tested logic and assets.
4. Secrets: if keysinhere.txt or any key is committed, delete it from the working tree, add it to .gitignore, add it to a list in docs/KEYS_ROTATE.md for the founder to rotate. Do not print key values anywhere.
5. Create docs/PLAN_STATUS.md with the goal list in section 6 and a checkbox for each. Commit and push (this is G0 done).

## 2. Non-negotiables
- Obey CLAUDE.md and every skill in .claude/skills (feature gate, privacy gate, design language, licence and secrets). Re-read them before each phase.
- No emojis anywhere in the app, code comments, copy or commits. Icons are open-source vector icons only (use Lucide, Phosphor or Tabler; check each licence and record it). User-typed emojis are replaced by an open-licence animated emoji set; pick one, verify the licence, record attribution in docs/THIRD_PARTY.md.
- Fonts: system font stacks first. If a web font is needed use an open-licence family (for example Inter or Geist under the SIL Open Font License), self-host it, record it in docs/THIRD_PARTY.md. No external font CDN (content delivery network) calls at runtime.
- Logos come from the repo (brand/, master/logos). Use the SVG files, never redraw them. Wordmark is KAMBi. The mascot stays as the 3D arch component in marketing only.
- Dependencies: MIT, Apache 2.0 or BSD only; flag and avoid GPL, AGPL, FSL, source-available. Log each new dependency in docs/THIRD_PARTY.md.
- No ClerQ text in any user-facing string, document template or public page. KAMBi is a Nama Labs venture; public name Kambi.camp.
- Copy is plain and grounded. No invented numbers, testimonials or field results. Hyphens only; no em or en dashes. Write the long form of acronyms on first use per document.
- English and Swahili for every non-HQ string via i18n files; HQ is English only. Check Swahili for natural phrasing; mark any machine-quality string in docs/I18N_REVIEW.md for a human check.
- Every collector action works offline. Every screen has designed empty, loading, offline, error and syncing states. Works at 360 px width, on low-end Android, with reduced-motion respected, 4.5:1 contrast, visible focus, 44 px touch targets.
- Real patient data never enters the system during development. Use clearly fake seed data only.

## 3. Business rules to encode (resolved)
- Pricing: first 100 entries free per account, then 100 TZS (Tanzanian shillings) per entry. Swahili shows "TSh 100"; English shows dollars from a daily online rate with fallback to TSh. Never guess a rate.
- Unpaid users receive only rule-based outputs: the system summary report with graphs (PDF) and a CSV or Excel export of their data. AI-written outputs, SMS (Short Message Service) follow-ups and publication are paid or quota-covered. No subscriptions.
- Retention: free-allowance, unpaid and past-quota entries are kept 90 days after the event closes, with in-app and SMS warnings at 30 and 7 days, then purged except de-identified aggregates. Paid and grant-covered entries are kept 365 days (365-day Entry Storage(TM)). The owner can export everything at any time and nothing is ever hidden or locked behind payment. Raw location 90 days then heat cells. Audit log is append-only, hash-chained, moved to cold storage after 90 days, never deleted.
- HQ quota grants: HQ can grant a camp or organization a limit-based quota (entries, SMS, AI) on prepaid or credit-line terms with an expiry, needing an approver and an audit event. Usage is metered against the grant and an invoice is generated at event close. Grant-covered entries count as paid for retention. The first partner (SIKI, Sauti Inayojenga Kesho Initiative) is configured through this mechanism, never hard-coded.
- Intelligent service: on sync, flag duplicates and missing required fields; never block capture.
- Publication to Zenodo and open platforms: built behind a feature flag, off by default; only de-identified data after the consent gate and owner confirmation.
- Roles and HQ rules, privacy fences, moderation flow, enterprise sandbox, QR slip and facility lookup flow: exactly as in CLAUDE.md and the feature tree.
- Camp one scope: Home, Camps, You visible; Library, Feed, Chat built and flagged off, each enabled by flipping a flag in HQ.

## 4. Free tiers and keys (do this, then wait)
Build every external service behind an adapter interface with two implementations: a real one that reads its key from environment variables, and a mock that works with no key. The default is mock whenever a key is absent. Services: Supabase (database, storage, realtime), Google sign-in, SMS (Textify Africa), payments (Payme Africa), AI (OpenRouter free models), exchange-rate API, push notifications, error tracking, analytics (Umami or PostHog self-host), Zenodo. Mocks must be good enough to run the whole app and the full test suite offline: fake SMS writes to a table visible in HQ, fake payments confirm through the HQ manual-confirmation path, fake AI returns labelled sample outputs.
Keep .env.example complete with variable names only. At the end write docs/KEYS_NEEDED.md: for every key, the exact variable name, the service and plan to use (free tier where it exists), where to obtain it, where it goes (Codespaces secret, Cloudflare Pages variable, Supabase secret, GitHub Actions secret), what breaks without it and what the mock does meanwhile. Never commit a secret. Never ask for a key mid-build.

## 5. Quality bar and design
Follow the Quiet Rail skill: content first, glass only on navigation and sheets, one ember accent, spring motion with three verbs (settle, lift, hand off), reduced motion honoured, desktop layouts with left navigation, Apple-grade polish, Android Material 3 Expressive behaviour. Build a shared design-tokens package (colour, type, radius, spacing, motion) used by every surface so the look is uniform. Build one component library with tests and a visual gallery page. Performance budget: first load under 200 KB gzipped on the marketing home excluding the 3D mascot chunk (lazy load it), interactive within 3 seconds on a mid-range Android on 3G. Accessibility and Swahili checks run in CI (continuous integration).

## 6. Plan goals (execute in order; each ends with commit and push)
G0 Repo map, plan status, secret cleanup, branch (section 1).
G1 Foundations F1 to F9: monorepo, environments, schema with row-level security and automated tenancy tests, auth with mock and Google adapters, role engine, audit log with hash chain and verifier, adapter layer and mocks, i18n, observability, pricing engine and exchange-rate adapter.
G2 Design system: tokens package, components, gallery, icon and emoji decisions recorded.
G3 HQ console core (H1 to H16, H19 to H24, F10 quota grants): all with tests and the role-gating test. HQ sign-in per RECONCILIATION item 8.
G4 Camp loop part 1: C1 to C7 (create, plan, forms, consent, team, goals) on the user app.
G5 Camp loop part 2: C8 to C13 offline capture, media downscale, registration, QR slip, sync and conflicts, telemetry. Run the airplane-mode simulation test with 100 entries.
G6 Review and outputs: C14 to C18, C19 retention tiers and purge job with warnings, C20 intelligent service, C22 rule-based outputs, AI outputs through the redaction pipeline and mocks.
G7 Facility follow-up E10 to E14 with the patient access log.
G8 Wallet, billing, SMS center, payments reconciliation, invoicing at close, grant metering.
G9 Enterprise console S4 sandbox plus the enterprise items that can be completed offline of keys; enterprise onboarding flow.
G10 Marketing site: drop in marketing-home files, wire Swahili and English across the whole page, Terms and Privacy pages (written with room for a future data marketplace and flagged for lawyer review), enterprise lead capture to HQ, performance budget met.
G11 Social and library behind flags: feed, stories, chats with push, forums, library, newsletter; moderation pipeline with mock models.
G12 Intelligence behind flags: I1 to I6.
G13 Hardening and full recheck: run gates G1 to G9 from the feature tree, secret scan, licence scan, full test suite, end-to-end flows, accessibility and 360 px checks, Android build config (Hermes, R8 and ProGuard, pinning, signing hooks) as far as possible without keys, performance run, Swahili completeness. Fix everything found. Write docs/RELEASE_CHECKLIST.md and docs/KEYS_NEEDED.md, docs/KEYS_ROTATE.md, docs/I18N_REVIEW.md, docs/THIRD_PARTY.md, docs/DECISIONS.md.
Then stop and wait for the founder to supply keys. When keys arrive, replace mocks one adapter at a time, run the adapter contract tests, commit and push after each.

## 7. Definition of done for the whole run
Every goal checked in docs/PLAN_STATUS.md with a pushed commit; pnpm install, lint, type check, test and build exit 0 from a clean clone; no secrets in the repo or bundles; no occurrence of "ClerQ" in user-facing files; every DONE condition in the feature tree marked pass or an explicit, reasoned blocker; KEYS_NEEDED.md complete.
