# Claude Code in GitHub Codespaces: setup, /goal and skills

## 1. Put Claude Code in the Codespace
1. Copy .devcontainer/devcontainer.json from this pack into the repo root (it uses Anthropic's official dev container feature and keeps your sign-in in a volume so it survives rebuilds). Commit and push.
2. On GitHub open the repo, press Code, then Codespaces, then Create. If the Codespace already exists, run the command palette action "Codespaces: Rebuild Container".
3. Open the terminal and run: claude --version. You need 2.1.139 or newer for /goal. If older, run: claude update.
4. Run: claude. Follow the sign-in prompt (it prints a link; open it in your browser and paste the code back). You need a Claude subscription or API credit; your Gemini key does not work with Claude Code.
5. To skip signing in for every new Codespace: on your own computer run claude setup-token, then save the token as a Codespaces secret named CLAUDE_CODE_OAUTH_TOKEN (GitHub, Settings, Codespaces, Secrets). Do not paste it into any file in the repo.

## 2. Give it its brain
Copy CLAUDE.md to the repo root, docs/ to docs/, and .claude/skills/ to .claude/skills/. Claude Code reads CLAUDE.md at the start of every session, and loads each skill when its description matches the task. Then start with: "Read CLAUDE.md and docs/RECONCILIATION.md, then list every DECISION NEEDED you cannot proceed without." Answer those first.

## 3. Autonomous work with /goal
/goal <condition> makes Claude keep working turn after turn until a separate small model (Haiku by default) reads the transcript and agrees the condition is met. It starts a turn immediately. Stop it with /goal clear or Ctrl+C. One goal per session; a new one replaces the old.
Rules that make it work:
- Describe an end state Claude can prove with command output, not effort. Good: tests, builds, grep results, file existence.
- Always include a stop clause so it cannot loop and burn credit: "or stop after 25 turns and write the blockers to TRACE.md".
- One feature ID per goal. Never "build the HQ console".
Examples:
- /goal Feature F2 is done: pnpm test passes including the RLS isolation tests, and TRACE.md has an F2 entry marking each DONE condition pass or fail. Stop after 25 turns and list blockers.
- /goal Feature C8 is done: the airplane-mode test captures 100 entries and the sync test uploads all 100 with zero duplicates, shown in test output. Stop after 30 turns.
- /goal The marketing home builds with pnpm build, has no occurrence of the word ClerQ (grep shows zero), and renders without horizontal scroll at 360 px width in the Playwright test. Stop after 20 turns.
Headless: claude -p "/goal <condition>" runs the whole loop in one command, good for overnight runs. Work on a branch, keep secrets out of the Codespace, and review the diff before merging. There is no spending cap per goal, so watch usage on the first runs.
Permissions: Shift+Tab cycles permission modes in the terminal; use the mode that auto-approves routine commands so it does not stop to ask, but keep it inside the Codespace, never on a machine holding real patient data.

## 4. Skills in this pack (.claude/skills)
- kambi-feature-gate: one feature ID, test first, DONE report, TRACE.md.
- kambi-privacy-gate: PDPA checklist before any feature touching personal data.
- kambi-design-language: Quiet Rail tokens, motion and copy rules.
- kambi-license-and-secrets: licence scan and secret leak checks.

More to add (verify each licence before use):
- Anthropic's official skills: in Claude Code run /plugin marketplace add anthropics/skills, then install what you need (documents, frontend design). Repo: github.com/anthropics/skills
- Official plugins directory: github.com/anthropics/claude-plugins-official
- Community lists: github.com/hesreallyhim/awesome-claude-code and github.com/alirezarezvani/claude-skills
- Docs: code.claude.com/docs/en/goal and code.claude.com/docs/en/devcontainer, and the feature at github.com/anthropics/devcontainer-features
- Writing your own: a folder with a SKILL.md that has name and description in its header; the repo template is at github.com/anthropics/skills (folder template).

## 5. Suggested first week
Day 1: answer the DECISION NEEDED list; run F1 and F2 as goals. Day 2: F3 to F6. Day 3: H1, H4, H6. Day 4 onward: Phase 2 features one goal each. After every phase run a goal that executes the full test suite and the G1 to G9 gates, and review TRACE.md yourself.

## 6. Run the whole build unattended
Copy scripts/run-goals.sh to the repo. It runs one /goal per phase (G0 to G13 in docs/MASTER_PROMPT.md), each in a fresh session, and the agent commits and pushes to branch build/revamp after every goal. Start it with: bash scripts/run-goals.sh. For a single interactive goal paste the /goal line from the script. Keep the Codespace awake (it times out after idle; raise the idle timeout in GitHub Codespaces settings) and watch usage on the first goal.
