# Reconciliation: conflicts between the three revamp PDFs, earlier decisions and the latest instructions

Rule used: the newest instruction wins, then the Revamp Spec, then older notes. "Default" is what the agent builds until the founder overrides. Every item except those marked Settled is a DECISION NEEDED.

| # | Topic | Conflict | Default adopted |
|---|---|---|---|
| 1 | Company and repo | PDF says "building under ClerQ" and repo ClerQ-Intelligence-CQ/Kambi. Later decision: KAMBi is a Nama Labs venture, ClerQ an affiliate; repo is Kambi-camp/Kambi. | Nama Labs and Kambi.camp. No ClerQ in user-facing text. Settled. |
| 2 | Account model | PDF: three planes. Earlier: exactly two account types (User, HQ). | Three planes, two kinds of person account. Enterprise is an organization entity with member roles. Settled. |
| 3 | Camp one scope | PDF V1 includes camp group chat, DMs and read-only Library. Earlier: camp one ships only Home, Camps, You; Feed, Library, Chat follow. | Narrow scope; every tab behind a flag so each opens with a flag flip. |
| 4 | First partner terms | PDF: free up to 500 entries. Earlier: fees waived, about 2,000 IDs, 25 TZS per follow-up. | Settled by the founder: no hard-coded partner rules. HQ grants SIKI a limit-based quota (prepaid or credit line) and bills at event close. Confirm figures against the signed MoU. |
| 5 | Pricing vs locked data | PDF N9 hides entries beyond quota. Earlier: raw records never locked. | Settled: nothing is hidden. Unpaid users get rule-based outputs only (summary report with graphs, CSV or Excel); AI and SMS are paid. |
| 6 | Media caps | PDF: 1 MB image inside a 5 MB entry cap. Earlier: 1 MB total per entry, 50 MB per event. | 1 MB per image, 5 MB per entry, 50 MB per event. Check storage cost. |
| 7 | Retention | Earlier 90 days; public promise 365 days; audit log append-only vs 90 days. | Settled: free allowance, unpaid and past-quota entries 90 days after close (warnings at 30 and 7 days, export always allowed); paid and grant-covered entries 365 days. Raw location 90 days then heat cells. Audit log append-only, cold storage after 90 days. Needs a storage cost check. |
| 8 | HQ sign-in | PDF: hardware MFA (multi-factor authentication). Earlier: email, password, secret key, security questions, no hardware key. | TOTP (time-based one-time password) app plus password plus secret key for all staff; hardware key mandatory for Master, Security and Finance once budget allows. Drop security questions (weak). |
| 9 | Refunds | PDF: Finance approval, capped at unused balance. Earlier: Finance, Security and Support all agree, 20% cap, Master alone can. | Both caps apply: at most 20% and at most unused balance. Three approvals unless Master. |
| 10 | User auth | PDF F3: phone or email code. Earlier: Google sign-in, no email-code flow, avoid Supabase Auth. | Google sign-in plus phone code over SMS. |
| 11 | Server layout | PDF: several small Oracle servers under an orchestrator. Risk: capacity errors, one builder. | One Oracle server first; add per proven bottleneck. |
| 12 | Knowledge graph | PDF I5 in V1 as personal-data-free; earlier: not now. | Phase 6, flag off. |
| 13 | HQ visibility | Earlier wanted "God-level" user visibility; PDF and PDPA push minimisation. | Aggregate and masked only; break-glass for anything identifiable. Settled by PDPA. |
| 14 | Badges and plans | Earlier: paid Pro and gold boosts. PDF: subscriptions ruled out. | Badges Phase 5 and later; no subscriptions. |
| 15 | Platforms | Repo is a Vite web app with Capacitor. PDF and later wishes: React Native (Expo EAS) plus PWA. | Rebuild S2 and S3 on Expo plus a PWA. Marketing home stays a Vite React page on its own Cloudflare project. |
| 16 | Localization | PDF F7: all screens in both languages. HQ English only. | HQ exempt. Marketing home: only pricing translated so far. |
| 17 | Real data before registration | Plan: test data until revenue proven. PDPA: register before collecting. The first camp collects hearing data of children. | Blocker: register and name a DPO before the camp, or run on test data only. Minors need guardian consent. |
| 18 | Camp date | Moved from 2 November to mid or late November, not announced. | Unknown; build to the earliest date. |

Added in this pack because none of the three PDFs covered them: the public marketing home with individual and enterprise paths, 365-day Entry Storage(TM), publication to Zenodo, the enterprise globe section, and the Claude Code workflow.
