# KAMBi Feature Tree (reconciled)

One feature ID per prompt. Paste its purpose and DONE condition; write the test first, then the code, then report which DONE conditions pass. Tags: [V1] before the first camp, [V2] after.

Surfaces: S1 marketing site, S2 user web and PWA (Progressive Web App), S3 Android (Expo EAS, Expo Application Services), S4 enterprise console, S5 HQ console, S6 orchestration on the VPS (virtual private server). Each console is its own Cloudflare Pages project. No client holds a service key.

## Phase 0 Foundations [V1]
- F1 Repo and environments. DONE: a push to staging deploys all surfaces; production needs manual approval.
- F2 Schema and RLS (row-level security). DONE: a test user cannot read another organization's rows, proved by automated tests.
- F3 Auth: Google sign-in and phone one-time code. DONE: expired and reused codes are rejected.
- F4 Role engine, server-side checks. DONE: an admin endpoint called as a normal user returns 403.
- F5 Audit log, append-only, hash-chained. DONE: edit or delete fails; the verifier detects a tampered chain.
- F6 Secrets and proxy. DONE: a search of the built app for key strings finds nothing.
- F7 Localization, English and Swahili (HQ English only). DONE: every non-HQ screen renders in both with no missing keys.
- F8 Observability. DONE: a forced error appears in the HQ job monitor within a minute.
- F9 Pricing engine: first 100 entries free, then 100 TZS each, daily USD rate with TSh fallback. DONE: bill equals ledger to the shilling; a failed rate fetch shows TSh, never a guessed dollar value.
- F10 HQ quota grants: limit-based quotas (entries, SMS, AI) on prepaid or credit-line terms with expiry, approver and audit event; invoice raised at event close. DONE: usage over the limit is blocked or billed per the grant terms; grant-covered entries count as paid.

## Phase 1 HQ console S5 [V1 minimum: H1 H2 H4 H6 H7 H9 H11 H12 H15 H19]
- H1 Account directory, masked. DONE: Support sees a masked phone and no health fields.
- H2 Enterprise verification queue. DONE: approve moves sandbox to live and notifies the owner.
- H3 Staff roles, second approver, recertification. DONE: a role change needs a second approver and writes an audit event.
- H4 Audit viewer, search, export. DONE: filter by actor, action and date; the export is itself logged.
- H5 Break-glass. DONE: reason code, auto-expiry, review ticket opened.
- H6 Wallet ledger. DONE: balance equals the sum of ledger entries; no direct edits.
- H7 Payment reconciliation. DONE: unmatched payments listed; confirming credits once only.
- H8 Refunds. DONE: required approvals met; at most 20% and at most unused balance.
- H9 Cost monitor and kill switch. DONE: crossing a camp's SMS or AI budget pauses its jobs and alerts HQ.
- H10 SMS center. DONE: delivery status per message; opt-outs respected.
- H11 Job and agent monitor. DONE: every cron run shows status; failures retry then land in a dead-letter list.
- H12 Sync health. DONE: backlog per device and app version visible.
- H13 Status board and maintenance mode. DONE: the toggle shows a banner on all apps.
- H14 Release control and feature flags. DONE: a flag change reaches clients without a new build.
- H15 Moderation queue. DONE: AI decision, AI audit and human override recorded; users can appeal.
- H16 Content admin. DONE: HQ can feature, remove and publish a newsletter.
- H17 camp oversight, H18 aggregate telemetry and heat maps, H21 decision dashboards, H22 support desk with masked view-as, H25 partnerships, H26 broadcasts. DONE each: list view, detail view, one action that writes an audit event.
- H19 Privacy operations: consent registry, data subject requests, breach register, processor register, retention jobs. DONE: an erasure request removes live data and queues backup purge.
- H20 AI governance. DONE: every AI call logs model, prompt version, fields sent and spend.
- H23 Security center. DONE: repeated failed sign-ins lock the account and alert Security.
- H24 Backups. DONE: a scheduled restore test passes and reports.
- Role gating test: each HQ role reaches its modules and gets 403 on all others.

## Phase 2 Camp loop S2 and S3 [V1]
- C1 Create camp (draft visible only to its admins). C2 Prepaid package or approved pilot terms (cannot go live otherwise).
- C3 Form builder with frozen versions. C4 Consent builder in English and Swahili naming purposes, recipients, partner facility and foreign processing (no consent step, no publish). C5 Team and collectors (removed collectors lose access immediately). C6 Goals and checklists. C7 Auto camp group [flag until Chat opens].
- C8 Offline capture. DONE: airplane mode captures 100 entries, then sync uploads all with no duplicates.
- C9 Photo and audio on-device downscale. DONE: a 6 MB photo is stored under 1 MB.
- C10 Registration and consent. DONE: no entry saves without a stored consent record; minors need guardian consent.
- C11 QR (Quick Response) slip: random signed expiring token, short backup code, facility details. DONE: scanning shows only a token lookup, never data.
- C12 Sync and conflicts. DONE: two devices editing one entry record a conflict, not silent loss.
- C13 Collector telemetry with permission. DONE: locations visible only when granted.
- C14 Entry browser and charts. C15 Exports (Excel, CSV, signed PDF; audit-logged; exclude withdrawn consent). C16 System summary per event on close, free. C17 AI outputs on anonymized fields; the redaction log proves no names or phones left.
- C18 Reflection report with one-tap clone to a new camp.
- C19 Retention tiers. DONE: paid and grant-covered entries are kept 365 days; free-allowance, unpaid and past-quota entries 90 days after close; owner warned at 30 and 7 days; export always works; nothing is hidden.
- C22 Rule-based outputs for everyone: summary report with graphs, and CSV or Excel. DONE: generated with no AI call and no payment.
- C20 Intelligent service. DONE: duplicates and missing required fields are flagged on sync; flags never block capture.
- C21 Publication to Zenodo and open platforms [flag off for camp one]. DONE: only de-identified data passes the consent gate; publishing needs owner confirmation and is audit-logged.

## Phase 3 Facility follow-up S4 and S3 [V1]
- E10 Partner facility link (the facility must accept).
- E11 Lookup console: authenticated clinician, scan or type code, one-time consent code to the patient's phone, minimum fields, outcome recorded. DONE: lookup fails without a valid consent code; every lookup appears in the patient access log.
- E12 Referral queue and reminders (unattended referrals trigger an SMS). E14 Patient-visible access log.

## Phase 4 Enterprise console S4 [V2 except sandbox]
E1 profile and verification, E2 roles, E3 seats, E4 official page, E5 affiliation inbox, E6 sub-units. DONE each: create, edit, permission check, audit event. E7 portfolio, E8 template library, E9 wallet and invoices, E13 exports, E15 sharing agreements, E16 branding, E17 API and webhooks, E18 compliance pack, E19 funder reports, E20 publishing, E21 priority support. DONE each: one end-to-end test. Sandbox: no real participant data while unverified.
Onboarding: type, verify, accept processing terms, owner with MFA, profile and roles, optional top-up, type-specific setup, guided first success (first camp, or a test lookup).

## Phase 5 Social and library [V2, each a flag off by default]
S-A feed, stories, repost, suggested follows, announcements, forums. S-B chats with real-time push and missed-message fetch. S-C home gamification and Wrapped. S-E library writing, letters, newsletter. Badges and boosts.

## Phase 6 Intelligence [flag off]
I1 anonymous analytics with a fixed schema. I2 HQ usage dashboard. I3 coarse device profile, no identifiers. I4 rules-based, explainable recommendations, switchable. I5 knowledge graph, personal-data-free, visible and clearable by the person. I6 demand heat map by district with a minimum cell count.

## S1 Marketing site [V1]
M1 Home with individual and enterprise paths, pricing, 365-day storage, Swahili and English pricing, enterprise section with dotted globe. DONE: no invented numbers, no ClerQ mentions, usable at 360 px width.
M2 Enterprise lead capture. DONE: a lead reaches HQ without exposing an inbox address.
M3 Terms and Privacy pages, written with room for a future data marketplace.

## Gates for every phase
G1 no secrets in client bundles. G2 server-side role checks. G3 Hermes, R8 and ProGuard on the Android build. G4 certificate pinning and request signing. G5 rate limits. G6 licence scan (MIT, Apache, BSD). G7 restore test before each camp. G8 privacy review before any feature touching personal data. G9 acceptable performance on low-end Android (Samsung, Infinix, Tecno class).
