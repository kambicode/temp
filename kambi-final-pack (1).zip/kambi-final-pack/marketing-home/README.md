Drop-in for main/apps/web/src/
- screens/MarketingLanding.tsx  (same props as before; App.tsx needs no change)
- components/KambiMascot3D.tsx  (unchanged copy of the repo mascot; needs three + @types/three, already in apps/web)
Removed on purpose: hidden HQ gateway (Ctrl+Shift+H, #ops, 5-tap), fake ticket form, invented field numbers, ClerQ badge.
