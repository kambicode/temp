#!/usr/bin/env bash
# Run from the repo root (the folder containing main/ and master/).
set -e
W=main/apps/web
sed -i '/clerq-logo.png/d' $W/public/sw.js
sed -i 's|ClerQ Intelligence Sovereign Protocol|KAMBi field protocol|' $W/src/screens/DynamicOnboardingDeck.tsx
sed -i 's|A ClerQ Intelligence product.|A Nama Labs venture.|' $W/src/screens/J7_Help.tsx
sed -i "s|name: 'ClerQ Intelligence'|name: 'KAMBi'|; s|handle: '@clerq'|handle: '@kambi'|" $W/src/screens/C1_Search.tsx
sed -i 's|^ClerQ Intelligence Research Infrastructure|KAMBi Research Infrastructure|; s| • ClerQ Intelligence • | • |' $W/public/downloads/KAMBi_Camp_Day_Paper_Fallback_Forms.txt
sed -i 's|^ClerQ Intelligence • KAMBi Research Infrastructure|KAMBi Research Infrastructure|' $W/public/downloads/KAMBi_Field_Volunteer_Quick_Guide.txt
sed -i 's|A ClerQ Intelligence product|A Nama Labs venture|' master/README.md
sed -i 's|^A \[ClerQ Intelligence\](https://github.com/ClerQ-Intelligence-CQ) product.|A Nama Labs venture.|' README.md
sed -i 's|A <a href="https://github.com/ClerQ-Intelligence-CQ">ClerQ Intelligence</a> product.|A Nama Labs venture.|; s|KAMBi, a ClerQ Intelligence product.|KAMBi, a Nama Labs venture.|' main/README.md
sed -i 's|ClerQ Intelligence Build Tool|KAMBi Build Tool|; s|ClerQ Android Key Tool|KAMBi Android Key Tool|; s|_CLERQ_INTELLIGENCE_2026|_2026|' main/scripts/package-apk.py
echo "Remaining (docs/ history left alone on purpose):"; grep -rIil clerq . --exclude-dir=node_modules --exclude-dir=.git --exclude=clean-clerq.sh || true
