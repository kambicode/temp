import { useEffect, useRef } from 'react';
import * as THREE from 'three';

/** Dotted globe, axis tilted, slow turn. Static when the person prefers reduced motion. */
export function DottedGlobe({ className = '' }: { className?: string }) {
  const ref = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const el = ref.current;
    if (!el) return;
    const w = el.clientWidth || 480;
    const h = el.clientHeight || 480;

    const scene = new THREE.Scene();
    const camera = new THREE.PerspectiveCamera(35, w / h, 0.1, 100);
    camera.position.z = 6.4;
    const renderer = new THREE.WebGLRenderer({ alpha: true, antialias: true });
    renderer.setSize(w, h);
    renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
    el.appendChild(renderer.domElement);

    const N = 2200;
    const pos = new Float32Array(N * 3);
    const golden = Math.PI * (3 - Math.sqrt(5));
    for (let i = 0; i < N; i++) {
      const y = 1 - (i / (N - 1)) * 2;
      const r = Math.sqrt(1 - y * y);
      const t = golden * i;
      pos[i * 3] = Math.cos(t) * r * 2;
      pos[i * 3 + 1] = y * 2;
      pos[i * 3 + 2] = Math.sin(t) * r * 2;
    }
    const geo = new THREE.BufferGeometry();
    geo.setAttribute('position', new THREE.BufferAttribute(pos, 3));
    const mat = new THREE.PointsMaterial({ color: 0xe9e4da, size: 0.032, transparent: true, opacity: 0.85, sizeAttenuation: true });
    const globe = new THREE.Points(geo, mat);
    const tilt = new THREE.Group();
    tilt.rotation.z = 0.41; // slight axial tilt
    tilt.rotation.x = 0.18;
    tilt.add(globe);
    scene.add(tilt);

    const still = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
    let raf = 0;
    const draw = () => {
      if (!still) globe.rotation.y += 0.0018;
      renderer.render(scene, camera);
      if (!still) raf = requestAnimationFrame(draw);
    };
    draw();

    return () => {
      cancelAnimationFrame(raf);
      geo.dispose();
      mat.dispose();
      renderer.dispose();
      renderer.domElement.remove();
    };
  }, []);

  return <div ref={ref} className={className} aria-hidden="true" />;
}
