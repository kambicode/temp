import { useEffect, useState } from 'react';
import { DottedGlobe } from '../components/DottedGlobe';
import { ArrowRight, Check, Smartphone, WifiOff, Lock, FileText, MapPin, Route, User, Building2 } from 'lucide-react';
import { KambiMascot3D } from '../components/KambiMascot3D';

interface MarketingLandingProps {
  onLaunchApp: () => void;
  onSignIn: () => void;
  onOpenDownloads?: () => void;
}

/*
  Quiet Rail home. One memorable thing (the mascot), everything else quiet.
  Rules: no emojis, no invented numbers, no chips, one ember accent used only
  for the primary action and the mascot. Springs/hover kept minimal.
*/
const ember = 'bg-[#D9501E] hover:bg-[#B43E14] text-white';

const guarantees = [
  { icon: WifiOff, title: 'Works without signal', body: 'Every entry is saved on the phone first and sent when a connection returns. Nothing waits on the network.' },
  { icon: Lock, title: 'Names stay apart from data', body: 'Identifying details are kept separate from the records used for analysis, and are never shown in reports.' },
  { icon: FileText, title: 'Reports without a laptop', body: 'A summary document and a spreadsheet of your data are ready when the event closes, at no charge.' },
];

const steps = [
  { title: 'Collect', body: 'Volunteers record each person in about a minute, online or off.' },
  { title: 'Hand over', body: 'Each person leaves with a slip tied to their record.' },
  { title: 'Continue', body: 'The health centre or institution you choose opens only that record, so care does not start from zero.' },
];

const domains = [
  'Community health and clinical outreach',
  'Agriculture and environmental surveys',
  'Markets, enterprise and economics',
  'Oral history and cultural heritage',
  'Any field study you can describe in a form',
];


type Lang = 'en' | 'sw';
const ENTRY_TZS = 100;
const FREE_ENTRIES = 100;

const copy = {
  en: {
    title: 'Start free. Then pay as you go.',
    lead: `Record your first ${FREE_ENTRIES} entries free. After that, each entry costs`,
    per: 'per entry',
    included: 'What you get',
    items: [
      ['365-day Entry Storage\u2122', 'Paid entries are kept for 365 days, searchable and recoverable. Entries on the free allowance are kept for 90 days, and you can export them at any time.'],
      ['Intelligent service', 'Entries are checked for duplicates and missing fields as they sync, and flagged for you to fix.'],
      ['Publication', 'Publish your findings to Zenodo and other open platforms when you choose. This opens in the weeks after our first camp.'],
    ],
    free: 'Always free: a rule-based summary report with graphs, and your data spreadsheet. AI-written reports and SMS follow-ups are charged per use, and you see the bill before you confirm.',
    rateNote: 'Shown in US dollars at the current exchange rate.',
  },
  sw: {
    title: 'Anza bure. Kisha lipa kadri unavyotumia.',
    lead: `Rekodi maingizo yako ${FREE_ENTRIES} ya kwanza bila malipo. Baada ya hapo, kila ingizo linagharimu`,
    per: 'kwa kila ingizo',
    included: 'Unachopata',
    items: [
      ['Hifadhi ya Maingizo ya Siku 365\u2122', 'Maingizo yaliyolipiwa huhifadhiwa kwa siku 365, yanatafutika na yanarejeshwa. Maingizo ya posho ya bure huhifadhiwa kwa siku 90, na unaweza kuyapakua wakati wowote.'],
      ['Huduma ya akili', 'Maingizo hukaguliwa kwa marudio na sehemu zilizoachwa wazi yanapotumwa, kisha unaarifiwa kuyarekebisha.'],
      ['Uchapishaji', 'Chapisha matokeo yako kwenye Zenodo na majukwaa mengine huria unapotaka. Hii inafunguliwa wiki chache baada ya kambi yetu ya kwanza.'],
    ],
    free: 'Bila malipo daima: ripoti ya muhtasari yenye michoro, na jedwali la data. Ripoti zilizoandikwa na AI na ujumbe wa SMS hutozwa kwa matumizi, na unaona bili kabla ya kuthibitisha.',
    rateNote: '',
  },
} as const;

function useEntryPrice(lang: Lang) {
  const [usdPerEntry, setUsdPerEntry] = useState<number | null>(null);
  useEffect(() => {
    if (lang !== 'en') return;
    let live = true;
    fetch('https://open.er-api.com/v6/latest/USD')
      .then((r) => r.json())
      .then((d) => {
        const tzs = d?.rates?.TZS;
        if (live && typeof tzs === 'number' && tzs > 0) setUsdPerEntry(ENTRY_TZS / tzs);
      })
      .catch(() => {});
    return () => { live = false; };
  }, [lang]);
  if (lang === 'sw') return `TSh ${ENTRY_TZS}`;
  // If the rate cannot be fetched, show the real shilling price rather than a guess.
  return usdPerEntry ? `$${usdPerEntry.toFixed(3)}` : `TSh ${ENTRY_TZS}`;
}

export function MarketingLanding({ onLaunchApp, onSignIn, onOpenDownloads }: MarketingLandingProps) {
  const [lang, setLang] = useState<Lang>(() =>
    typeof navigator !== 'undefined' && navigator.language?.toLowerCase().startsWith('sw') ? 'sw' : 'en',
  );
  const price = useEntryPrice(lang);
  const t = copy[lang];
  return (
    <div className="min-h-screen bg-[#FBFAF8] text-[#161513] antialiased selection:bg-[#D9501E]/20">
      <header className="sticky top-0 z-40 bg-[#FBFAF8]/90 backdrop-blur-xl border-b border-[#E6E3DD]">
        <div className="max-w-6xl mx-auto px-5 h-16 flex items-center justify-between">
          <a href="#top" className="text-[17px] font-semibold tracking-tight">KAMBi</a>
          <nav className="hidden md:flex items-center gap-7 text-[14px] text-[#5E5B55]">
            <a href="#how" className="hover:text-[#161513]">How it works</a>
            <a href="#audiences" className="hover:text-[#161513]">Who it is for</a>
            <a href="#fields" className="hover:text-[#161513]">Fields</a>
            <a href="#contact" className="hover:text-[#161513]">Contact</a>
            {onOpenDownloads && (
              <button type="button" onClick={onOpenDownloads} className="hover:text-[#161513]">Download</button>
            )}
          </nav>
          <div className="flex items-center gap-4">
            <button type="button" onClick={() => setLang(lang === 'en' ? 'sw' : 'en')} className="text-[14px] text-[#5E5B55] hover:text-[#161513]" aria-label="Change language">{lang === 'en' ? 'Kiswahili' : 'English'}</button>
            <button type="button" onClick={onSignIn} className="text-[14px] text-[#5E5B55] hover:text-[#161513]">Sign in</button>
            <button type="button" onClick={onLaunchApp} className={`h-10 px-4 rounded-[10px] text-[14px] font-medium ${ember}`}>Open KAMBi</button>
          </div>
        </div>
        <nav className="md:hidden flex gap-6 overflow-x-auto px-5 pb-3 text-[14px] text-[#5E5B55] [scrollbar-width:none]">
          <a href="#how" className="shrink-0">How it works</a>
          <a href="#audiences" className="shrink-0">Who it is for</a>
          <a href="#fields" className="shrink-0">Fields</a>
          <a href="#contact" className="shrink-0">Contact</a>
          {onOpenDownloads && <button type="button" onClick={onOpenDownloads} className="shrink-0">Download</button>}
        </nav>
      </header>

      <main id="top">
        <section className="max-w-6xl mx-auto px-5 pt-14 pb-20 md:pt-24 md:pb-28 grid lg:grid-cols-12 gap-12 items-center">
          <div className="lg:col-span-7">
            <h1 className="text-[40px] sm:text-[56px] leading-[1.04] font-semibold tracking-[-0.035em] max-w-[16ch]">
              Field data that reaches the next hand.
            </h1>
            <p className="mt-6 text-[18px] leading-[1.55] text-[#5E5B55] max-w-[46ch]">
              KAMBi is the research tool for medical camps, outreaches and field studies. Collect without signal, produce your reports, and let a person's record travel to the place that will use it.
            </p>
            <div className="mt-9 flex flex-wrap items-center gap-3">
              <button type="button" onClick={onLaunchApp} className={`h-12 px-6 rounded-[12px] text-[15px] font-medium inline-flex items-center gap-2 ${ember}`}>
                Open KAMBi <ArrowRight size={16} />
              </button>
              {onOpenDownloads && (
                <button type="button" onClick={onOpenDownloads} className="h-12 px-5 rounded-[12px] border border-[#D8D4CC] hover:border-[#161513] text-[15px] inline-flex items-center gap-2 transition-colors">
                  <Smartphone size={16} /> Install on your phone
                </button>
              )}
            </div>
          </div>

          <div className="lg:col-span-5">
            <div className="rounded-[24px] bg-white border border-[#E6E3DD] overflow-hidden aspect-square">
              <KambiMascot3D className="w-full h-full" />
            </div>
            <p className="mt-3 text-[13px] text-[#8A867E] text-center">Drag to turn it.</p>
          </div>
        </section>

        <section id="how" className="border-t border-[#E6E3DD] bg-white">
          <div className="max-w-6xl mx-auto px-5 py-20 md:py-28 grid lg:grid-cols-12 gap-12">
            <div className="lg:col-span-4">
              <h2 className="text-[30px] sm:text-[36px] leading-[1.1] font-semibold tracking-[-0.025em]">We build the rails, not the archive.</h2>
              <p className="mt-4 text-[15px] leading-[1.65] text-[#5E5B55] max-w-[38ch]">
                Your data stays yours. KAMBi carries it from the camp to the reminder to the referral, and opens it only to the people you permit.
              </p>
            </div>
            <ol className="lg:col-span-8 grid sm:grid-cols-3 gap-8">
              {steps.map((s, i) => (
                <li key={s.title} className="border-t-2 border-[#161513] pt-4">
                  <span className="text-[13px] text-[#8A867E]">Step {i + 1}</span>
                  <h3 className="mt-1 text-[18px] font-semibold">{s.title}</h3>
                  <p className="mt-2 text-[14px] leading-[1.6] text-[#5E5B55]">{s.body}</p>
                </li>
              ))}
            </ol>
          </div>
        </section>

        <section className="border-t border-[#E6E3DD]">
          <div className="max-w-6xl mx-auto px-5 py-20 md:py-28 grid md:grid-cols-3 gap-10">
            {guarantees.map(({ icon: Icon, title, body }) => (
              <div key={title}>
                <Icon size={22} className="text-[#161513]" strokeWidth={1.6} />
                <h3 className="mt-4 text-[18px] font-semibold">{title}</h3>
                <p className="mt-2 text-[14px] leading-[1.65] text-[#5E5B55] max-w-[34ch]">{body}</p>
              </div>
            ))}
          </div>
        </section>

        <section id="audiences" className="border-t border-[#E6E3DD]">
          <div className="max-w-6xl mx-auto px-5 py-20 md:py-28">
            <h2 className="text-[30px] sm:text-[36px] leading-[1.1] font-semibold tracking-[-0.025em] max-w-[22ch]">One account for people. A separate door for institutions.</h2>
            <div className="mt-12 grid md:grid-cols-2 gap-6">
              <div className="rounded-[20px] border border-[#E6E3DD] bg-white p-7 sm:p-9 flex flex-col">
                <User size={22} strokeWidth={1.6} />
                <h3 className="mt-5 text-[22px] font-semibold">For individuals</h3>
                <p className="mt-2 text-[15px] leading-[1.6] text-[#5E5B55]">Volunteers, researchers, students and readers. The same account can run one event and take part in another.</p>
                <ul className="mt-5 space-y-2 text-[15px] leading-[1.55] flex-1">
                  <li>Create or join an event and collect on your phone.</li>
                  <li>Get your summary document and data spreadsheet free.</li>
                  <li>Read published field research from across Africa.</li>
                </ul>
                <button type="button" onClick={onLaunchApp} className={`mt-7 h-12 px-6 rounded-[12px] text-[15px] font-medium inline-flex items-center gap-2 self-start ${ember}`}>Open KAMBi <ArrowRight size={16} /></button>
              </div>
              <div className="rounded-[20px] bg-[#161513] text-[#FBFAF8] p-7 sm:p-9 flex flex-col">
                <Building2 size={22} strokeWidth={1.6} />
                <h3 className="mt-5 text-[22px] font-semibold">For health centres and institutions</h3>
                <p className="mt-2 text-[15px] leading-[1.6] text-[#B9B5AC]">Receive people referred from camps with the record that belongs to them, so treatment or follow-up does not start from zero.</p>
                <ul className="mt-5 space-y-2 text-[15px] leading-[1.55] flex-1">
                  <li>Open only the record tied to a person's slip or ID.</li>
                  <li>Every access is permitted, limited and logged.</li>
                  <li>Partner terms for organisations that run camps regularly.</li>
                </ul>
                <a href="mailto:kambi.camp@gmail.com?subject=Institution%20enquiry" className="mt-7 h-12 px-6 rounded-[12px] text-[15px] font-medium inline-flex items-center gap-2 self-start border border-[#4A4741] hover:border-[#FBFAF8] transition-colors">Talk to us <ArrowRight size={16} /></a>
              </div>
            </div>
          </div>
        </section>

        <section id="fields" className="border-t border-[#E6E3DD] bg-white">
          <div className="max-w-6xl mx-auto px-5 py-20 md:py-28 grid lg:grid-cols-12 gap-12">
            <div className="lg:col-span-5">
              <h2 className="text-[30px] sm:text-[36px] leading-[1.1] font-semibold tracking-[-0.025em]">Medicine is one template, not the limit.</h2>
              <p className="mt-4 text-[15px] leading-[1.65] text-[#5E5B55] max-w-[40ch]">
                The same capture, sync and reporting work for any study where people with phones gather information in the field.
              </p>
            </div>
            <ul className="lg:col-span-7 divide-y divide-[#E6E3DD] border-y border-[#E6E3DD]">
              {domains.map((d) => (
                <li key={d} className="py-4 text-[17px] flex items-center gap-3">
                  <MapPin size={16} className="text-[#8A867E]" strokeWidth={1.6} /> {d}
                </li>
              ))}
            </ul>
          </div>
        </section>

        <section id="pricing" className="border-t border-[#E6E3DD] bg-white">
          <div className="max-w-6xl mx-auto px-5 py-20 md:py-28 grid lg:grid-cols-12 gap-12">
            <div className="lg:col-span-5">
              <h2 className="text-[30px] sm:text-[36px] leading-[1.1] font-semibold tracking-[-0.025em] max-w-[16ch]">{t.title}</h2>
              <p className="mt-5 text-[16px] leading-[1.6] text-[#5E5B55] max-w-[40ch]">{t.lead}</p>
              <p className="mt-3 text-[44px] leading-none font-semibold tracking-[-0.03em]">{price} <span className="text-[16px] font-normal text-[#5E5B55] tracking-normal">{t.per}</span></p>
              {t.rateNote && lang === 'en' && price.startsWith('$') && <p className="mt-2 text-[13px] text-[#8A867E]">{t.rateNote}</p>}
            </div>
            <div className="lg:col-span-7">
              <h3 className="text-[15px] font-semibold">{t.included}</h3>
              <ul className="mt-4 divide-y divide-[#E6E3DD] border-y border-[#E6E3DD]">
                {t.items.map(([name, body]) => (
                  <li key={name} className="py-5 flex gap-4">
                    <Check size={18} strokeWidth={1.8} className="mt-1 shrink-0" />
                    <div>
                      <p className="text-[17px] font-semibold">{name}</p>
                      <p className="mt-1 text-[14px] leading-[1.6] text-[#5E5B55] max-w-[52ch]">{body}</p>
                    </div>
                  </li>
                ))}
              </ul>
              <p className="mt-5 text-[14px] leading-[1.6] text-[#5E5B55] max-w-[56ch]">{t.free}</p>
            </div>
          </div>
        </section>

        <section id="enterprise" className="relative overflow-hidden border-t border-[#E6E3DD] bg-[#161513] text-[#FBFAF8]">
          <DottedGlobe className="pointer-events-none absolute left-0 top-1/2 h-[340px] w-[340px] md:h-[540px] md:w-[540px] -translate-x-1/3 -translate-y-1/2 opacity-40 md:opacity-100" />
          <div className="relative z-10 max-w-6xl mx-auto px-5 py-24 md:py-32 md:pl-[380px] min-[1500px]:pl-5">
            <h2 className="text-[30px] sm:text-[40px] leading-[1.08] font-semibold tracking-[-0.03em] max-w-[18ch]">Enterprise solutions for institutions that receive and serve people.</h2>
            <p className="mt-5 text-[16px] leading-[1.6] text-[#B9B5AC] max-w-[52ch]">
              Health centres, universities, NGOs and ministries run KAMBi across many camps and sites, with one place to manage access, records and billing.
            </p>
            <div className="mt-9 flex flex-wrap gap-3">
              <a href="mailto:kambi.camp@gmail.com?subject=Enterprise%20-%20get%20started" className={`h-12 px-6 rounded-[12px] text-[15px] font-medium inline-flex items-center gap-2 ${ember}`}>Get started <ArrowRight size={16} /></a>
              <a href="mailto:kambi.camp@gmail.com?subject=Enterprise%20-%20find%20out%20more" className="h-12 px-6 rounded-[12px] text-[15px] font-medium inline-flex items-center border border-[#4A4741] hover:border-[#FBFAF8] transition-colors">Find out more</a>
            </div>
          </div>
        </section>

        <section id="contact" className="border-t border-[#E6E3DD] bg-[#161513] text-[#FBFAF8]">
          <div className="max-w-6xl mx-auto px-5 py-20 md:py-24 flex flex-col md:flex-row md:items-end md:justify-between gap-8">
            <div>
              <h2 className="text-[30px] sm:text-[36px] leading-[1.1] font-semibold tracking-[-0.025em] max-w-[18ch]">Planning a camp or a study?</h2>
              <p className="mt-3 text-[15px] text-[#B9B5AC] max-w-[44ch]">Write to us with the date and the place. A person replies.</p>
            </div>
            <a
              href="mailto:kambi.camp@gmail.com?subject=Planning%20a%20camp%20or%20study"
              className={`h-12 px-6 rounded-[12px] text-[15px] font-medium inline-flex items-center gap-2 self-start md:self-auto ${ember}`}
            >
              kambi.camp@gmail.com <ArrowRight size={16} />
            </a>
          </div>
        </section>
      </main>

      <footer className="border-t border-[#E6E3DD] py-8 text-[13px] text-[#8A867E]">
        <div className="max-w-6xl mx-auto px-5 flex flex-col sm:flex-row justify-between gap-2">
          <span>KAMBi, Dar es Salaam. A Nama Labs venture.</span>
          <span>Version 1.0.0</span>
        </div>
      </footer>
    </div>
  );
}
