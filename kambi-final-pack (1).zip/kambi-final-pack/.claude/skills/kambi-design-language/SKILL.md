---
name: kambi-design-language
description: Use when designing or coding any KAMBi screen, component, animation, icon, empty state or piece of user-facing copy, on web, Android, iPhone PWA or desktop.
---

# Quiet Rail design language

Sources: Rams (as little design as possible, honest, thorough), Ive (care in unseen details, inevitability), Bernays (symbol and ritual used ethically), typography stays in the background.
- Content is the material; chrome recedes. Glass only on navigation, toolbars and sheets, never behind reading text.
- Palette: warm paper neutrals, one ember accent (#D9501E family) for the primary action and live or sync state only.
- Type: system face per platform, tight scale, generous white space.
- Motion: springs; three verbs only: settle, lift, hand off (a record moving between people). Honour reduced motion.
- Android follows Material 3 Expressive spring motion and shape morph; Apple follows system springs and continuous corners; desktop has left navigation.
- No emojis in app chrome or icons (vector icons only); user text uses the built-in animated emoji set. No preset chips, tags or pills.
- Copy: plain, grounded, no filler, no invented numbers or testimonials. Use hyphens only, never em or en dashes.
- Every state is designed: empty, loading, offline, failed, syncing. Works at 360 px width and on low-end Android.
- Text is 16 px minimum for body, 4.5:1 contrast, visible keyboard focus.
