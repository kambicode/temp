---
name: kambi-privacy-gate
description: Use before building or changing any KAMBi feature that collects, stores, shows, exports, sends or analyses personal or health data, including AI, SMS, analytics and facility lookup. Checks Tanzania PDPA obligations.
---

# Privacy gate (Tanzania PDPA, Personal Data Protection Act)

Answer each item with evidence from the code before finishing:
- Notice: the person is told purposes and recipients before collection (s23).
- Consent: written, versioned, withdrawable; names the partner facility and any foreign processing; guardian consent for minors (s30).
- Minimisation: only fields the purpose needs; identifiers stay apart from research data.
- AI: names, phones and national IDs never leave the device or server in a model call; the redaction log records which fields were sent.
- Corrections keep earlier versions (s29). Erasure and export requests work (N10).
- Access: server-side role check; every lookup writes to the append-only audit log and is visible to the person on request.
- Security: no secrets in clients; proportional measures documented.
- Marketing and reminders: opt-out respected (s35). No solely automated decision without a human appeal path (s36).
- Vendors: processor contract exists for any new SMS, AI or hosting vendor.
If any item fails, stop and report it instead of shipping. Real patient data is never entered until the founder confirms registration with the Personal Data Protection Commission.
