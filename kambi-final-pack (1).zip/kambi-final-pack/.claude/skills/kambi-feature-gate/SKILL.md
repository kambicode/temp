---
name: kambi-feature-gate
description: Use when implementing, changing or reviewing any KAMBi feature that has an ID in docs/KAMBI_FEATURE_TREE.md (F, H, C, E, S, I, M series). Enforces test-first work, a DONE report and TRACE.md logging.
---

# Feature gate

1. Name the feature ID and quote its DONE condition from docs/KAMBI_FEATURE_TREE.md. If there is none, stop and ask.
2. Write the failing test that proves the DONE condition. Run it and show it fail.
3. Write the smallest code that passes. Keep business logic and role checks on the server.
4. Run the full test suite, lint and type check.
5. Append to TRACE.md: date, feature ID, files changed, each DONE condition marked pass or fail with evidence, open risks.
6. Do not start another feature ID in the same pass. Never mark a phase complete without an audit and a checkpoint entry.
7. Anything marked DECISION NEEDED: use the default in docs/RECONCILIATION.md and note it in TRACE.md.
