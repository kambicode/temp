---
name: kambi-license-and-secrets
description: Use when adding or upgrading any dependency, copying code from another project, or touching environment variables, API keys, build configs or anything committed to the repo.
---

# Licence and secrets check

Dependencies: only MIT, Apache 2.0 or BSD. Before adding one, read its licence and last commit date. Flag GPL, AGPL, FSL (Functional Source License) and other source-available licences and stop for a decision. Do not copy code from Mastodon, Discourse or Element without checking licence terms. Record each new dependency and its licence in TRACE.md.
Secrets: none in the repo, a client bundle, an APK, a log or a screenshot. Keys live in server functions or the secrets store. Before every commit run a secret scan (gitleaks config exists in the repo) and grep the built bundle for key patterns. If a secret was ever committed (the file keysinhere.txt is a known case), say so, rotate the key and remove it from history. Environment files stay out of git; .env.example holds names only.
